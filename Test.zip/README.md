# chatbot
This is a simple project that will help you learn how to build a chatbot using flutter and dialogflow

You can read an article about this project, which is on medium: https://medium.com/flutter-community/build-a-chatbot-in-20-minutes-using-flutter-and-dialogflow-8e9af1014463


Screenshots:

<img src="https://github.com/Wizpna/chatbot/blob/master/screenshot/Screenshot_20190728-214356.png"  title="chatbot">

Contact - Let's become friends

<a href="https://twitter.com/Promise_Amadi1">Twitter</a></br>
<a href="https://github.com/Wizpna">Github</a></br>
<a href="https://www.linkedin.com/in/promise-amadi-101759a1/">Linkedin</a></br>


